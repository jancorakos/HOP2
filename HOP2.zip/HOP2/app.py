﻿from flask import Flask, render_template, request, send_from_directory
import csv
import io
import json
import math
import os

app = Flask(__name__)

DEFAULT_TIME = 5  
UPLOAD_FOLDER = 'static'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Funkcia na načítanie dát
def load_data(clerks_file, form_counts_file):
    # Načítanie clerks dát
    with open(clerks_file, 'r', encoding='utf-8') as f:
        clerks_raw = json.load(f)

    # Načítanie form counts dát
    with open(form_counts_file, 'r', encoding='utf-8') as f:
        form_counts = json.load(f)

    # Handling clerks_raw structure variations
    if isinstance(clerks_raw, list):
        # Handling list format: List of clerks, each being a dictionary of form_type: time
        clerks_raw = [
            {form_type: time if time != -1 else None for form_type, time in clerk.items()}
            for clerk in clerks_raw
        ]
    elif isinstance(clerks_raw, dict):
        # Handling dictionary format: Dict of clerk_id: {form_type: time}
        clerks_raw = [
            {form_type: time if time != -1 else None for form_type, time in clerk_data.items()}
            for clerk_data in clerks_raw.values()
        ]
    else:
        raise ValueError("Unsupported format for clerks_raw data")

    # Handle form_counts structure
    if not isinstance(form_counts, dict):
        raise ValueError("form_counts should be a dictionary")
    
    # Ensure all form types have positive counts
    for form_type, count in form_counts.items():
        if not isinstance(count, int) or count < 0:
            raise ValueError(f"Invalid count for form {form_type}: {count}")

    return clerks_raw, form_counts

# Funkcia na generovanie CSV
def generate_csv_table(assignment):
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Zapisujeme údaje do CSV
    for u, forms in assignment.items():
        if forms:  # Ak úradník má priradené formuláre
            writer.writerow([u] + forms)
        else:
            writer.writerow([])  # Ak úradník nemá žiadne formuláre
    
    output.seek(0)
    
    # Parsovanie CSV do zoznamu riadkov
    csv_content = list(csv.reader(output))
    
    return csv_content

# Funkcia na výpočet času
def base_time(u, t, clerk_times):
    times = clerk_times[u]
    if t in times:
        return times[t]  # Returns None if the clerk cannot process this form
    return DEFAULT_TIME  # Default time if form is not in the clerk's list

def worker_total_time(u, forms, clerk_times):
    total = 0.0
    last_type = None
    run_length = 0

    for t in forms:
        p = base_time(u, t, clerk_times)
        if p is None:
            raise ValueError(f"Úradník {u} nevie spracovať {t}")

        if t == last_type:
            run_length += 1
        else:
            last_type = t
            run_length = 1

        discount = 1 - 0.05 * (run_length - 1)
        discount = max(discount, 0.5)
        effective_p = p * discount

        total += effective_p

    return total

def worker_wage(total_minutes):
    return 30.0 * math.ceil(total_minutes / 60.0)

def evaluate_assignment(assignment, clerk_times):
    times = {}
    wages = {}
    for u, forms in assignment.items():
        Cu = worker_total_time(u, forms, clerk_times)
        Wu = worker_wage(Cu)
        times[u] = Cu
        wages[u] = Wu

    C_max = max(times.values()) if times else 0.0
    W = sum(wages.values())
    return C_max, W

# Greedy algoritmus pre priradenie formulárov
def greedy_assignment(clerks_raw, form_counts):
    clerk_times = []
    for clerk in clerks_raw:
        times = {}
        for form_type, minutes in clerk.items():
            # Handle case where time might be None (unprocessed form)
            if minutes is None:
                times[form_type] = None
            else:
                times[form_type] = minutes
        clerk_times.append(times)

    assignment = {u: [] for u in range(len(clerks_raw))}

    # Nastavenie váh pre čas a náklady
    w_time = 0.5  # váha pre čas
    w_wage = 0.5  # váha pre náklady

    for form_type, count in form_counts.items():
        for _ in range(count):
            best_score = float('inf')
            best_assignment = None

            for u in range(len(clerks_raw)):
                if base_time(u, form_type, clerk_times) is not None:
                    # Hlboká kópia zoznamov
                    temp_assignment = {k: v.copy() for k, v in assignment.items()}
                    temp_assignment[u].append(form_type)

                    # Získame hodnoty pre čas a mzdu
                    C_max, W = evaluate_assignment(temp_assignment, clerk_times)

                    # Kombinované skóre: vážený priemer medzi časom a mzdovými nákladmi
                    combined_score = w_time * C_max + w_wage * W

                    if combined_score < best_score:
                        best_score = combined_score
                        best_assignment = temp_assignment

            if best_assignment is None:
                raise ValueError(f"Žiadny úradník nevie spracovať formulár typu {form_type}")

            assignment = best_assignment

    return assignment

# Hlavná stránka (index)
@app.route('/')
def index():
    return render_template('index.html')

# Spracovanie nahraných súborov
@app.route('/process', methods=['POST'])
def process_files():
    # Získanie nahraných súborov z formulára
    clerks_file = request.files.get('clerks_file')
    form_counts_file = request.files.get('form_counts_file')

    if not clerks_file or not form_counts_file:
        return "Please upload both clerks data and form counts files.", 400

    # Uloženie nahraných súborov do dočasného adresára
    clerks_path = os.path.join(UPLOAD_FOLDER, 'clerks_data.json')
    form_counts_path = os.path.join(UPLOAD_FOLDER, 'form_counts_data.json')

    clerks_file.save(clerks_path)
    form_counts_file.save(form_counts_path)

    # Načítanie dát z nahraných súborov
    clerks_raw, form_counts = load_data(clerks_path, form_counts_path)
    
    # Spracovanie formulárov pomocou greedy algoritmu
    assignment = greedy_assignment(clerks_raw, form_counts)

    # Generovanie CSV zo spracovaných dát
    csv_content = generate_csv_table(assignment)

    # Výpočet C_max a W
    clerk_times = []
    for clerk in clerks_raw:
        times = {}
        for form_type, minutes in clerk.items():
            if minutes == -1:
                times[form_type] = None
            else:
                times[form_type] = minutes
        clerk_times.append(times)

    C_max, W = evaluate_assignment(assignment, clerk_times)

    # Uloženie CSV na disk
    csv_filename = os.path.join(UPLOAD_FOLDER, 'output.csv')
    with open(csv_filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        for row in csv_content:
            writer.writerow(row)

    # Zobrazenie stránky s výsledkami a CSV tabuľkou
    return render_template('index.html', csv_content=csv_content, C_max=C_max, W=W, csv_filename='output.csv')

# Na stiahnutie CSV súboru
@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

if __name__ == '__main__':
    app.run(debug=True)
